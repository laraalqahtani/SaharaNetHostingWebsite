﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using SaharaHosting.Models;
using System;

namespace SaharaHosting.Controllers
{
    public class HomeController : Controller
    {


        private static List<Plan> _plans = new List<Plan>
        {
            new Plan { Id = 1, Plan_Name = "Start Up", Storage = "5 GB", Bandwidth = "20 GB", Price = "250 SAR" },
            new Plan { Id = 2, Plan_Name = "Advanced", Storage = "10 GB", Bandwidth = "50 GB", Price = "500 SAR" },
            new Plan { Id = 3, Plan_Name = "Premium", Storage = "20 GB", Bandwidth = "50 GB", Price = "1300 SAR" }
        };

                private static List<Order> _orders = new List<Order>
        {
            new Order { Id = 1, ClientId = 1, PlanId = 1, ClientName = "Ali", PlanName = "Start Up", Storage = "5 GB", Bandwidth = "20 GB", Price = "250 SAR", Date = DateTime.Now.AddMonths(-1) },
            new Order { Id = 2, ClientId = 2, PlanId = 2, ClientName = "Sara", PlanName = "Advanced", Storage = "10 GB", Bandwidth = "50 GB", Price = "500 SAR", Date = DateTime.Now.AddMonths(-2) },
            new Order { Id = 3, ClientId = 3, PlanId = 3, ClientName = "Mohammed", PlanName = "Premium", Storage = "20 GB", Bandwidth = "50 GB", Price = "1300 SAR", Date = DateTime.Now.AddMonths(-3) },
            new Order { Id = 4, ClientId = 4, PlanId = 1, ClientName = "Norah", PlanName = "Start Up", Storage = "5 GB", Bandwidth = "20 GB", Price = "250 SAR", Date = DateTime.Now.AddMonths(-1) }
        };

                private static List<Client> _clients = new List<Client>
        {
            new Client { Id = 1, Name = "Ali", Email = "ali@example.com", Phone = "123456789", CreatedDate = DateTime.Now.AddYears(-1) },
            new Client { Id = 2, Name = "Sara", Email = "sara@example.com", Phone = "987654321", CreatedDate = DateTime.Now.AddYears(-2) },
            new Client { Id = 3, Name = "Mohammed", Email = "Mohammed@example.com", Phone = "948732898", CreatedDate = DateTime.Now.AddYears(-3) },
            new Client { Id = 4, Name = "Norah", Email = "norah@example.com", Phone = "0938298339", CreatedDate = DateTime.Now.AddYears(-1) }
        };


        public IActionResult Index()
        {
            ViewBag.ActiveClients = _clients.Count;
            ViewBag.ActivePlans = _plans.Count;
            ViewBag.OrdersCount = _orders.Count;
            return View();
        }

        public IActionResult Clients()
        {
            return View(_clients);
        }

        public IActionResult AddClient()
        {
            return View();
        }

        public IActionResult Support()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddClient(Client client)
        {
            if (ModelState.IsValid)
            {
                client.Id = _clients.Any() ? _clients.Max(c => c.Id) + 1 : 1;
                _clients.Add(client);
                return RedirectToAction("Clients");
            }
            return View(client);
        }

        public IActionResult EditClient(int id)
        {
            var client = _clients.FirstOrDefault(c => c.Id == id);
            if (client == null)
            {
                return NotFound();
            }
            return View(client);
        }

        [HttpPost]
        public IActionResult EditClient(Client client)
        {
            if (ModelState.IsValid)
            {
                var existingClient = _clients.FirstOrDefault(c => c.Id == client.Id);
                if (existingClient != null)
                {
                    existingClient.Name = client.Name;
                    existingClient.Email = client.Email;
                    existingClient.Phone = client.Phone;
                    return RedirectToAction("Clients");
                }
                return NotFound();
            }
            return View(client);
        }

        public IActionResult DeleteClient(int id)
        {
            var client = _clients.FirstOrDefault(c => c.Id == id);
            if (client != null)
            {
                _clients.Remove(client);
            }
            return RedirectToAction("Clients");
        }

        public IActionResult Plans()
        {
            return View(_plans);
        }

        public IActionResult AddPlan()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddPlan(Plan plan)
        {
            if (ModelState.IsValid)
            {
                plan.Id = _plans.Any() ? _plans.Max(c => c.Id) + 1 : 1;
                _plans.Add(plan);
                return RedirectToAction("Plans");
            }
            return View(plan);
        }

        public IActionResult EditPlan(int id)
        {
            var plan = _plans.FirstOrDefault(c => c.Id == id);
            if (plan == null)
            {
                return NotFound();
            }
            return View(plan);
        }

        [HttpPost]
        public IActionResult EditPlan(Plan plan)
        {
            if (ModelState.IsValid)
            {
                var existingPlan = _plans.FirstOrDefault(c => c.Id == plan.Id);
                if (existingPlan != null)
                {
                    existingPlan.Plan_Name = plan.Plan_Name;
                    existingPlan.Storage = plan.Storage;
                    existingPlan.Bandwidth = plan.Bandwidth;
                    existingPlan.Price = plan.Price;
                    return RedirectToAction("Plans");
                }
                return NotFound();
            }
            return View(plan);
        }

        public IActionResult DeletePlan(int id)
        {
            var plan = _plans.FirstOrDefault(c => c.Id == id);
            if (plan != null)
            {
                _plans.Remove(plan);
            }
            return RedirectToAction("Plans");
        }

        public IActionResult Orders()
        {
            var orders = _orders.Select(o => new Order
            {
                Id = o.Id,
                ClientName = _clients.FirstOrDefault(c => c.Id == o.ClientId)?.Name,
                PlanName = _plans.FirstOrDefault(p => p.Id == o.PlanId)?.Plan_Name,
                Storage = _plans.FirstOrDefault(p => p.Id == o.PlanId)?.Storage,
                Bandwidth = _plans.FirstOrDefault(p => p.Id == o.PlanId)?.Bandwidth,
                Price = _plans.FirstOrDefault(p => p.Id == o.PlanId)?.Price
            }).ToList();

            return View(orders);
        }

        public IActionResult AddOrder()
        {
            var model = new OrderViewModel
            {
                Clients = _clients,
                Plans = _plans
            };
            return View(model);
        }

        [HttpPost]
        public IActionResult AddOrder(OrderViewModel model)
        {
            if (model.ClientId == 0 || model.PlanId == 0)
            {
                ModelState.AddModelError("", "Client and Plan must be selected.");
                model.Clients = _clients;
                model.Plans = _plans;
                return View(model);
            }

            var orderId = _orders.Any() ? _orders.Max(o => o.Id) + 1 : 1;

            var plan = _plans.FirstOrDefault(p => p.Id == model.PlanId);
            var client = _clients.FirstOrDefault(c => c.Id == model.ClientId);

            if (plan != null && client != null)
            {
                _orders.Add(new Order
                {
                    Id = orderId,
                    ClientId = model.ClientId,
                    PlanId = model.PlanId,
                    ClientName = client.Name,
                    PlanName = plan.Plan_Name,
                    Storage = plan.Storage,
                    Bandwidth = plan.Bandwidth,
                    Price = plan.Price
                });

                return RedirectToAction("Orders");
            }

            ModelState.AddModelError("", "Invalid Client or Plan.");
            model.Clients = _clients;
            model.Plans = _plans;
            return View(model);
        }

        public IActionResult Billing()
        {
            // Pass billing info to the view
            var billingInfos = _orders.Select(o => new BillingInfo
            {
                Id = o.Id,
                ClientName = o.ClientName,
                PlanName = o.PlanName,
                Amount = decimal.Parse(o.Price.Replace(" SAR", "")), // Remove currency symbol
                Date = DateTime.Now // Use the current date or adjust as needed
            }).ToList();

            return View(billingInfos);
        }

        // Method to get billing data for chart
        public IActionResult GetBillingData()
        {
            var billingData = _orders.GroupBy(o => o.ClientName)
                .Select(g => new
                {
                    ClientName = g.Key,
                    TotalAmount = g.Sum(o => decimal.Parse(o.Price.Replace(" SAR", "")))
                })
                .ToList();

            return Json(billingData);
        }

        public IActionResult GetOrdersData()
        {
            var data = _orders.GroupBy(o => o.Date.ToString("MMM yyyy"))
                .Select(g => new
                {
                    Label = g.Key,
                    Value = g.Count()
                })
                .OrderBy(d => d.Label)
                .ToList();

            return Json(new
            {
                labels = data.Select(d => d.Label).ToArray(),
                values = data.Select(d => d.Value).ToArray()
            });
        }


        public IActionResult GetClientsData()
        {
            var data = _clients.GroupBy(c => c.CreatedDate.Year)
                .Select(g => new
                {
                    Label = g.Key.ToString(),
                    Value = g.Count()
                })
                .OrderBy(d => d.Label)
                .ToList();

            return Json(new
            {
                labels = data.Select(d => d.Label).ToArray(),
                values = data.Select(d => d.Value).ToArray()
            });
        }


    }
}
