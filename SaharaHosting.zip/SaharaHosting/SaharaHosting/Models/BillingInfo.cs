﻿using System;
namespace SaharaHosting.Models
{
    public class BillingInfo
    {
        public int Id { get; set; }
        public string ClientName { get; set; }
        public string PlanName { get; set; }
        public decimal Amount { get; set; }
        public DateTime Date { get; set; }
    }

}

