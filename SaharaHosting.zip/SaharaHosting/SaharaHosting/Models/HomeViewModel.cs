﻿using System;
namespace SaharaHosting.Models
{
	public class HomeViewModel
	{

		public int ActiveClients { get; set; }
		public int ActivePlans { get; set; }
        public int OrdersCount { get; set; }

    }
	
}

