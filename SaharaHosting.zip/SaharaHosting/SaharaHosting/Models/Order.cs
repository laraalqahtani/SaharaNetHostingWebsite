﻿using System;

namespace SaharaHosting.Models
{
    public class Order
    {
        public int Id { get; set; }
        public int ClientId { get; set; }
        public int PlanId { get; set; }
        public string ClientName { get; set; }
        public string PlanName { get; set; }
        public string Storage { get; set; }
        public string Bandwidth { get; set; }
        public string Price { get; set; }
        public DateTime Date { get; set; }
    }
}
