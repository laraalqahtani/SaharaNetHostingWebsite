﻿using System;
namespace SaharaHosting.Models
{
    public class OrderViewModel
    {
        public int ClientId { get; set; }
        public int PlanId { get; set; }
        public IEnumerable<Client> Clients { get; set; }
        public IEnumerable<Plan> Plans { get; set; }
    }
}
