﻿using System;
namespace SaharaHosting.Models
{
    public class Plan
    {
        public int Id { get; set; }
        public string Plan_Name { get; set; }
        public string Storage { get; set; }
        public string Bandwidth { get; set; }
        public string Price { get; set; }
    }

}

